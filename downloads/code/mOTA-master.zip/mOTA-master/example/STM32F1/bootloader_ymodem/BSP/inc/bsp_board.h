#ifndef __BSP_BOARD_H__
#define __BSP_BOARD_H__


#include "bsp_common.h"


void BSP_Board_Init(void);


#endif

