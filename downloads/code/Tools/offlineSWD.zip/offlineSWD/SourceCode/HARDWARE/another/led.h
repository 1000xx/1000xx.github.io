#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

#define DEBUG_LED PBout(4)// PB4

void LED_Init(void);

		 				    
#endif
