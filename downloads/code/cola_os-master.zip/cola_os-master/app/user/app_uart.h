#ifndef _APP_UART_H_
#define _APP_UART_H_

void app_uart_init(void);


#endif 
