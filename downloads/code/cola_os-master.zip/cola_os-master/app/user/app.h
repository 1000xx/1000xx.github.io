#ifndef _APP_H_
#define _APP_H_


void app_init(void);


#endif 
