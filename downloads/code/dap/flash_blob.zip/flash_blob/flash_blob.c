#include "stm32f10x_flash.h"

/* Flash Access Control Register bits */
#define ACR_LATENCY_Mask         ((uint32_t)0x00000038)
#define ACR_HLFCYA_Mask          ((uint32_t)0xFFFFFFF7)
#define ACR_PRFTBE_Mask          ((uint32_t)0xFFFFFFEF)

/* Flash Access Control Register bits */
#define ACR_PRFTBS_Mask          ((uint32_t)0x00000020) 

/* Flash Control Register bits */
#define CR_PG_Set                ((uint32_t)0x00000001)
#define CR_PG_Reset              ((uint32_t)0x00001FFE) 
#define CR_PER_Set               ((uint32_t)0x00000002)
#define CR_PER_Reset             ((uint32_t)0x00001FFD)
#define CR_MER_Set               ((uint32_t)0x00000004)
#define CR_MER_Reset             ((uint32_t)0x00001FFB)
#define CR_OPTPG_Set             ((uint32_t)0x00000010)
#define CR_OPTPG_Reset           ((uint32_t)0x00001FEF)
#define CR_OPTER_Set             ((uint32_t)0x00000020)
#define CR_OPTER_Reset           ((uint32_t)0x00001FDF)
#define CR_STRT_Set              ((uint32_t)0x00000040)
#define CR_LOCK_Set              ((uint32_t)0x00000080)

/* FLASH Mask */
#define RDPRT_Mask               ((uint32_t)0x00000002)
#define WRP0_Mask                ((uint32_t)0x000000FF)
#define WRP1_Mask                ((uint32_t)0x0000FF00)
#define WRP2_Mask                ((uint32_t)0x00FF0000)
#define WRP3_Mask                ((uint32_t)0xFF000000)
#define OB_USER_BFB2             ((uint16_t)0x0008)

/* FLASH Keys */
#define RDP_Key                  ((uint16_t)0x00A5)
#define FLASH_KEY1               ((uint32_t)0x45670123)
#define FLASH_KEY2               ((uint32_t)0xCDEF89AB)

/* FLASH BANK address */
#define FLASH_BANK1_END_ADDRESS   ((uint32_t)0x807FFFF)

/* Delay definition */   
#define EraseTimeout          ((uint32_t)0x000B0000)
#define ProgramTimeout        ((uint32_t)0x00002000)

#define BKPT(v) __asm { BKPT v }

// #pragma arm section code = "RAMCODE"
void BreakPoint(int r0, char* r1, int len, int r3)
{ 
   int c, temp;
   
   BKPT(0) 
   for(; len; len--,r1++) {
      temp = *r1<<24;
      r0 ^= temp;
      for(c=8; c; c--) { 
          temp = r0; 
          r0 <<= 1; 
          if(temp&0x80000000) { 
              r0 ^= r3; 
          }
      }
   }
}

int Init()
{ 
    // https://blog.csdn.net/qq_43666306/article/details/109311798
    // 1, FPEC键寄存器 (FLASH_KEYR)
    // 其中FPEC总共有3个键值：
    // RDPRT键 = 0X000000A5 用于解除读保护
    // KEY1 = 0X45670123 用于解除闪存锁
    // KEY2 = 0XCDEF89AB 用于解除闪存锁
    
    FLASH->ACR = 0; // 0x40022000
    FLASH->KEYR = FLASH_KEY1; // 0x45670123, unlock Flash Lock 
    FLASH->KEYR = FLASH_KEY2; // 0xCDEF89AB, unlock Flash Lock 
    if(FLASH->OBR&4) {        // User Option: IWDG_SW(Bit0) is Set
        IWDG->KR = 0x5555; 
        IWDG->PR = 6; 
        IWDG->RLR = 0xFFF; 
    }
    return 0; 
}

int UnInit(void) 
{
    FLASH->CR |= CR_LOCK_Set; 
    return 0; 
} 

int EraseChip(void)
{
    FLASH->CR |= CR_MER_Set;  // 0x04
    FLASH->CR |= CR_STRT_Set; // 0x40
    while(FLASH->SR&FLASH_FLAG_BSY) { 
        IWDG->KR = 0xAAAA; 
    }
    FLASH->CR &= CR_MER_Reset; 
    return 0; 
}

int EraseSector(int sectorNum) 
{
    FLASH->CR |= CR_PER_Set; // 0x02 
    FLASH->AR = sectorNum; 
    FLASH->CR |= CR_STRT_Set; // 0x40
    while(FLASH->SR&FLASH_FLAG_BSY) { 
        IWDG->KR = 0xAAAA; 
    }
    FLASH->CR &= CR_PER_Reset; 
    return 0; 
}

int ProgramPage(char* dst, int size, char* src, int len) 
{ 
    // Align 2 bytes
    size += 1; 
    size &= ~1; 
    
    for(; size; size-=2) { 
        FLASH->CR |= CR_PG_Set; // 0x01 
        *((uint16_t*)dst) = *((uint16_t*)src); 
        __NOP();
        while(FLASH->SR&FLASH_FLAG_BSY); 
        FLASH->CR &= CR_PG_Reset;  
        if(FLASH->SR&(FLASH_FLAG_PGERR|FLASH_FLAG_WRPRTERR)) { 
            FLASH->SR |= FLASH_FLAG_PGERR|FLASH_FLAG_WRPRTERR; 
            return 1; 
        }
        dst += 2; 
        src += 2; 
    }
    return 0; 
}

int ReadPage(char* dst, int size, int addr) 
{
    // Align 2 bytes
    size += 1; 
    size &= ~1; 
	
		for(; size; size-=2) { 
				*((uint16_t*)dst) = *((uint16_t*)addr); 
        dst += 2; 
        addr += 2; 
		}
    return 0; 
}

#pragma arm section

#if 1
int main(void)
{
		char buf[0x400] = { 0 }; 
	
		ReadPage(buf, 0x400, 0x1FFFF000); 
		return 0; 
}
#endif 
